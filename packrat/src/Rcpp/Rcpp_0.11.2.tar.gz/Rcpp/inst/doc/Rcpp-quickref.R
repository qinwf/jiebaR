### R code from vignette source 'Rcpp-quickref.Rnw'

###################################################
### code chunk number 1: Rcpp-quickref.Rnw:28-32
###################################################
options( width= 50)
library( "Rcpp" )
prettyVersion <- packageDescription("Rcpp")$Version
prettyDate <- format(Sys.Date(), "%B %e, %Y")


